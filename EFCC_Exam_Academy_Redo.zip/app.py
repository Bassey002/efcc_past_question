"""EFCC Exam Academy: independent preparation tool (not affiliated with EFCC)."""
import csv
import io
import json
import random
import time
from datetime import datetime
from html import escape
from pathlib import Path

import streamlit as st

st.set_page_config(page_title="EFCC Exam Academy", page_icon="📘", layout="wide", initial_sidebar_state="collapsed")
ROOT = Path(__file__).resolve().parent
BANK = json.loads((ROOT / "questions.json").read_text(encoding="utf-8"))
SUBJECTS = list(dict.fromkeys(q["subject"] for q in BANK))
LETTERS = "ABCD"

st.markdown("""<style>
[data-testid="stAppViewContainer"]{background:#f3f6fa;color:#162b40}
.block-container{max-width:1080px;padding-top:1.1rem;padding-bottom:4rem}
.hero{background:linear-gradient(115deg,#10283f,#145f65);padding:26px 30px;border-radius:18px;color:white;margin-bottom:18px}
.hero h1{font-size:clamp(1.6rem,4vw,2.3rem);color:white;margin:0}
.hero p{color:#d7eeed;margin:8px 0 0}
.question{background:white;border:1px solid #dce5ef;border-radius:16px;padding:24px;margin:16px 0}
.question .meta{font-size:.78rem;font-weight:700;color:#467085;letter-spacing:.06em}
.question h3{font-size:1.2rem;line-height:1.55;color:#132a42;margin:10px 0 0}
[data-testid="stMetric"]{background:white;border:1px solid #dce5ef;border-radius:13px;padding:14px}
.stButton>button[kind="primary"]{background:#126d68;border-color:#126d68}
@media(max-width:600px){.hero{padding:18px}.question{padding:16px}}
</style>""", unsafe_allow_html=True)

if "exam" not in st.session_state:
    st.session_state.exam = None
if "history" not in st.session_state:
    st.session_state.history = []


def begin(mode, subject, count, duration, shuffle):
    pool = [q for q in BANK if subject == "All subjects" or q["subject"] == subject]
    rng = random.Random()
    picked = rng.sample(pool, count) if shuffle else pool[:count]
    now = time.time()
    st.session_state.exam = {
        "mode": mode, "subject": subject, "questions": picked, "responses": {},
        "index": 0, "started": now, "deadline": now + duration * 60,
        "duration": duration, "submitted": False, "submitted_at": None,
    }
    st.rerun()


def submit():
    ex = st.session_state.exam
    if ex["submitted"]:
        return
    ex["submitted"] = True
    ex["submitted_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    score = sum(ex["responses"].get(str(q["id"])) == q["answer"] for q in ex["questions"])
    st.session_state.history.append({"date": ex["submitted_at"], "mode": ex["mode"], "score": score, "total": len(ex["questions"])})


def export_csv(ex):
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["Question", "Subject", "Question text", "Selected answer", "Correct answer", "Correct?", "Explanation"])
    for n, q in enumerate(ex["questions"], 1):
        selected = ex["responses"].get(str(q["id"]))
        writer.writerow([n, q["subject"], q["question"], q["options"][selected] if selected is not None else "Unanswered", q["options"][q["answer"]], selected == q["answer"], q["explanation"]])
    return buffer.getvalue().encode("utf-8-sig")


st.markdown('<div class="hero"><h1>📘 EFCC Exam Academy</h1><p>Assistant Superintendent II • Practice, timed CBT and detailed solutions</p></div>', unsafe_allow_html=True)
st.caption("Independent educational preparation resource. 100 original EFCC-style questions; not official past papers and not affiliated with the EFCC.")
ex = st.session_state.exam

if ex is None:
    a, b, c = st.columns(3)
    a.metric("Questions", len(BANK))
    b.metric("Subjects", len(SUBJECTS))
    c.metric("Learning modes", "2")
    st.subheader("Create a test")
    with st.container(border=True):
        mode = st.radio("Mode", ["Practice", "Timed CBT"], horizontal=True)
        subject = st.selectbox("Question category", ["All subjects"] + SUBJECTS)
        available = sum(subject == "All subjects" or q["subject"] == subject for q in BANK)
        counts = [n for n in (5, 10, 20, 40, 60, 80, 100) if n <= available]
        count = st.select_slider("Number of questions", options=counts, value=(counts[-1] if mode == "Timed CBT" else 10))
        duration = st.number_input("Time limit (minutes)", min_value=5, max_value=240, value=60, step=5, disabled=mode == "Practice")
        shuffle = st.toggle("Randomise question order", value=True)
        st.info("Practice reveals the solution after you choose an answer. Timed CBT hides solutions until submission and auto-submits when the timer expires.")
        if st.button("Start " + mode, type="primary", use_container_width=True):
            begin(mode, subject, count, int(duration), shuffle)
    st.subheader("Question bank")
    for s in SUBJECTS:
        st.write(f"**{s}:** {sum(q['subject'] == s for q in BANK)} questions")
    if st.session_state.history:
        st.subheader("Results from this browser session")
        st.dataframe(st.session_state.history, hide_index=True, use_container_width=True)
        st.caption("History is stored only in this active Streamlit session and may disappear when it closes.")
    st.stop()

if ex["mode"] == "Timed CBT" and not ex["submitted"] and time.time() >= ex["deadline"]:
    submit()
    st.warning("Time expired. The examination was submitted automatically.")

if ex["submitted"]:
    qs = ex["questions"]
    score = sum(ex["responses"].get(str(q["id"])) == q["answer"] for q in qs)
    total = len(qs)
    unanswered = sum(str(q["id"]) not in ex["responses"] for q in qs)
    st.subheader("Your examination result")
    a, b, c = st.columns(3)
    a.metric("Correct", f"{score}/{total}")
    b.metric("Score", f"{100 * score / total:.1f}%")
    c.metric("Unanswered", unanswered)
    st.progress(score / total)
    st.caption(f"Submitted: {ex['submitted_at']}")
    st.subheader("Performance by subject")
    for subject in SUBJECTS:
        sub = [q for q in qs if q["subject"] == subject]
        if sub:
            n = sum(ex["responses"].get(str(q["id"])) == q["answer"] for q in sub)
            st.write(f"**{subject} — {n}/{len(sub)}**")
            st.progress(n / len(sub))
    st.download_button("Download detailed result (CSV)", export_csv(ex), "efcc_exam_result.csv", "text/csv", use_container_width=True)
    st.subheader("Review all answers")
    for i, q in enumerate(qs, 1):
        selected = ex["responses"].get(str(q["id"]))
        ok = selected == q["answer"]
        with st.expander(f"{'✅' if ok else '❌'} {i}. {q['question']}"):
            st.write("**Your answer:** " + (f"{LETTERS[selected]}. {q['options'][selected]}" if selected is not None else "Unanswered"))
            st.write(f"**Correct answer:** {LETTERS[q['answer']]}. {q['options'][q['answer']]}")
            st.info("**Explanation:** " + q["explanation"])
    if st.button("Start another test", type="primary", use_container_width=True):
        st.session_state.exam = None
        st.rerun()
    st.stop()

idx = ex["index"]
q = ex["questions"][idx]
key = str(q["id"])
answered = len(ex["responses"])
n = len(ex["questions"])

head, action = st.columns([3, 1])
head.markdown(f"**{ex['mode']}** · Question {idx+1} of {n}")
with action:
    if st.button("Exit test", use_container_width=True):
        st.session_state.exam = None
        st.rerun()

if ex["mode"] == "Timed CBT":
    @st.fragment(run_every="1s")
    def live_clock():
        current = st.session_state.exam
        if current is None or current["submitted"]:
            return
        remaining = max(0, int(current["deadline"] - time.time()))
        st.markdown(f"**⏱ Time remaining: {remaining // 60:02d}:{remaining % 60:02d}**")
        if remaining == 0:
            submit()
            st.rerun(scope="app")
    live_clock()
else:
    st.caption("Practice mode: explanations appear immediately after an answer is selected.")
st.progress(answered / n)
st.caption(f"{answered} of {n} answered")
st.markdown(f'<div class="question"><div class="meta">{escape(q["subject"].upper())} • QUESTION {idx+1}</div><h3>{escape(q["question"])}</h3></div>', unsafe_allow_html=True)

# Radio widget keys are per question. Once a selection is made, the answer is stored.
current = ex["responses"].get(key)
choice = st.radio("Choose your answer", range(4), format_func=lambda i: f"{LETTERS[i]}. {q['options'][i]}", index=current, key=f"answer_{q['id']}")
if choice is not None:
    ex["responses"][key] = choice
if ex["mode"] == "Practice" and choice is not None:
    if choice == q["answer"]:
        st.success("Correct answer")
    else:
        st.error("Not correct — review the worked explanation.")
    st.markdown(f"**Correct answer:** {LETTERS[q['answer']]}. {q['options'][q['answer']]}")
    st.info("**Explanation:** " + q["explanation"])

left, right = st.columns(2)
with left:
    if st.button("← Previous", disabled=idx == 0, use_container_width=True):
        ex["index"] -= 1
        st.rerun()
with right:
    if st.button("Next →", disabled=idx == n-1, use_container_width=True):
        ex["index"] += 1
        st.rerun()

with st.expander("Question navigator", expanded=False):
    st.caption("● Answered · ○ Unanswered")
    columns = st.columns(5)
    for i, item in enumerate(ex["questions"]):
        marked = str(item["id"]) in ex["responses"]
        if columns[i % 5].button(f"{'●' if marked else '○'} {i+1}", key=f"jump_{i}", use_container_width=True):
            ex["index"] = i
            st.rerun()

st.divider()
if st.button("Submit test and see results", type="primary", use_container_width=True):
    submit()
    st.rerun()
