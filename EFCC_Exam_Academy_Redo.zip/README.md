# EFCC Exam Academy

A responsive Python Streamlit learning and CBT practice application for candidates preparing for the Assistant Superintendent of EFCC II recruitment examination.

**Disclaimer:** Independent educational material. The 100 questions are original practice questions, not authenticated EFCC past papers. This application is not affiliated with, approved by, or endorsed by the Economic and Financial Crimes Commission.

## Start locally

1. Install Python 3.10 or newer.
2. Extract this ZIP into a folder.
3. Open Terminal / Command Prompt in that folder.
4. Install dependencies: `python -m pip install -r requirements.txt`
5. Start: `python -m streamlit run app.py`
6. Open the local URL shown in your terminal (normally http://localhost:8501).

## Features

- 100 questions, 20 each in Mathematics, English, Logical Reasoning, EFCC and General Knowledge, and Computer Literacy.
- Practice mode with instant correct-answer explanations.
- Timed CBT with a live timer and automatic submission when time expires.
- Choose subject, test size, and whether to randomise questions.
- Previous/next navigation and a jump-to-question grid.
- Result score, percentage, unanswered count, subject-level performance, full answer review.
- Download results as a CSV file.
- Mobile-friendly Streamlit layout.

## Hosting

Create a GitHub repository with `app.py`, `questions.json`, and `requirements.txt` at its root. On Streamlit Community Cloud, choose the repository and set the entrypoint to `app.py`.

## Notes

- No account system, payments, or permanent database are included.
- Results history lasts only for the active Streamlit session; download CSV results for your records.
- The timer is enforced by the application during the active browser session. A production high-stakes testing service would require server-side identity verification, persistence, and additional security.
- You may edit `questions.json` to revise or expand the bank. Each question has `id`, `subject`, `question`, four `options`, a zero-based `answer` index, and an `explanation`.
